# cdm-loader-rdbms

additional code to load different RDBMS with the CDM 